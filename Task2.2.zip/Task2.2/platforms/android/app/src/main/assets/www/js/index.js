/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    document.getElementById("powerForm").addEventListener("submit", function(event) {
        event.preventDefault();
        const formData = new FormData(event.target);
        const x = parseFloat(formData.get("base"));
        const y = parseFloat(formData.get("exponent"));
        const result = power(x, y);
        alert(x + " raised to the power " + y + " is: " + result);
    });

    function power(x, y) {
        // Base case: if y is 0, return 1
        if (y === 0) {
            return 1;
        }
        // If y is negative, compute reciprocal
        if (y < 0) {
            return 1 / power(x, -y);
        }
        // If y is odd, recursively compute x^(y-1) and multiply it by x
        if (y % 2 !== 0) {
            return x * power(x, y - 1);
        }
        // If y is even, recursively compute x^(y/2) and square it
        return power(x * x, Math.floor(y / 2));
    }
}
