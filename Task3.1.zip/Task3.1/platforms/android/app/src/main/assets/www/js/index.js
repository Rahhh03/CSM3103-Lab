/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    document.getElementById("productForm").addEventListener("submit", function(event) {
        event.preventDefault();
    
        // Get the form data
        var productName = document.getElementById("productName").value;
        var quantity = parseInt(document.getElementById("quantity").value);
        var price = parseFloat(document.getElementById("price").value);
    
        // Create a product object
        var product = {
            productName: productName,
            quantity: quantity,
            price: price
        };
    
        // Display product information
        alert("Product Name: " + product.productName +
            "\nQuantity: " + product.quantity +
            "\nPrice: $" + product.price.toFixed(2));
    
        // Optionally, you can reset the form after submission
        document.getElementById("productForm").reset();
    });
    
}
