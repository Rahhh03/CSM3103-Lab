/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

// Wait for the deviceready event before using any of Cordova's device APIs.
// See https://cordova.apache.org/docs/en/latest/cordova/events/events.html#deviceready
document.addEventListener('deviceready', onDeviceReady, false);

function onDeviceReady() {
    // Parent object: Employee
    function Employee(employeeName, employeeId, salary) {
        this.employeeName = employeeName;
        this.employeeId = employeeId;
        this.salary = salary;
    }

    // Child object: Manager (inherits from Employee)
    function Manager(employeeName, employeeId, salary, managerName, branch) {
        Employee.call(this, employeeName, employeeId, salary);
        this.managerName = managerName;
        this.branch = branch;
    }

    // Inherit properties from Employee
    Manager.prototype = Object.create(Employee.prototype);
    Manager.prototype.constructor = Manager;

    // Function to handle form submission
    document.getElementById("employeeForm").addEventListener("submit", function(event) {
        event.preventDefault();

        // Get the form data
        var employeeName = document.getElementById("employeeName").value;
        var employeeId = document.getElementById("employeeId").value;
        var salary = parseFloat(document.getElementById("salary").value);
        var managerName = document.getElementById("managerName").value;
        var branch = document.getElementById("branch").value;

        // Create a new Manager object
        var manager = new Manager(employeeName, employeeId, salary, managerName, branch);

        // Display all properties of the manager
        alert("Employee Name: " + manager.employeeName +
            "\nEmployee ID: " + manager.employeeId +
            "\nSalary: RM" + manager.salary.toFixed(2) +
            "\nManager Name: " + manager.managerName +
            "\nBranch: " + manager.branch);

        // Optionally, you can reset the form after submission
        document.getElementById("employeeForm").reset();
    });
}
